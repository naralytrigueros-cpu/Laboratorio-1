/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import com.microsoft.sqlserver.jdbc.SQLServerException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author naral
 */
public class Conexion {
    public Conexion() {
    }
    //--Metodo de conexion 
    public static Connection getConexion() throws SQLException 
    {                //Paramentros para establecer la conexion 
        String cadenaConexion = "jdbc:sqlserver://localhost:1433;" + //Controlador jdbc, servidor y su puerto 
                                "database=SistemaVuelos;" + //Base de datos a usar 
                                "user=sa;" + //Usuario de coneccion a sql 
                                "password=12345;" + //clave de conexion a sql
                                "encrypt=true;" + //conexion encriptada 
                                "trustServerCertificate= true;" ; //certificado de confianza
        
        try {
            //Establecer una conexion con los parametros dados
            Connection con = DriverManager.getConnection(cadenaConexion);
            return con;
        } catch (SQLServerException ex){
            JOptionPane.showMessageDialog(null, ex.toString());
            return null;
        }
    }
    
    public static int accesoLogin(String User, String Password) throws SQLException {
        int resultado = 0;
        
        //-- SQL requiere try catch
        try {
            //--Declarar la conexion a sql server 
            Statement sql = (Statement )Conexion.getConexion().createStatement();
            //-- Variable con la sentenia o script sql
            String consulta = " Select *  "+
                              " From Usuarios "+
                              " Where NomUsr = '" + User + "' "+
                              " And Clave = '" + Password + "' ";
            //--Ejecutar la consulta y llenar una estructura con el o los resultados obtenidos
            
            ResultSet rs = sql.executeQuery(consulta);
            while (rs.next() ) {
                //-resultado = Integer.valueOf( rs.getString(1) );
                resultado = rs.getInt(1);
            }
            
        }catch (SQLServerException e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return resultado;
    }
    
}

